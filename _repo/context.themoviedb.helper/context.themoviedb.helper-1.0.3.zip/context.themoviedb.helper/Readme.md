
# TheMovieDb Helper Additional Context Menu Items [![License](https://img.shields.io/badge/License-GPLv3-blue)](https://github.com/jurialmunkey/context.themoviedb.helper/blob/master/LICENSE.txt)


Kodi Versions:

- [Leia](https://github.com/jurialmunkey/context.themoviedb.helper/tree/leia)
- [Matrix](https://github.com/jurialmunkey/context.themoviedb.helper/tree/matrix)
